#ifndef ft245r_h
#define ft245r_h

#include "pgm.h"

extern const char ft245r_desc[];
void ft245r_initpgm (PROGRAMMER * pgm);


#endif /* ft245r_h */
